class HeapNode:
    def __init__(self, char, freq):
        self.char = char
        self.freq = freq
        self.left = None
        self.right = None

my_string = input("Enter the string to compress")
len_my_string = len(my_string)
print("Your message is:")
print(my_string)
print("Your data is", len_my_string * 8, "bits long")

letters = []
only_letters = []
for letter in my_string:
    if letter not in letters:
        freq: int = my_string.count(letter)
        letter.append(freq)
        letter.append(letter)
        only_letters.append(letter)

nodes = []
while len(letters) > 0:
    nodes.append(letters[0:2])
    nodes = nodes[2:]
    nodes.sort()
    huffman_tree = []
    huffman_tree.append(nodes)

def combine(nodes):
    pos = 0
    newnode = []

    ##get the lowest nodes

    if len(nodes) > 0:
        nodes.sort()
        nodes[pos].append("0")
        nodes[pos + 1].append("1")
        combined_node1 = (nodes[pos][0] + nodes[pos + 1][0])
        combined_node2 = (nodes[pos][1]) + (nodes[pos + 1][1])
        newnode.append(combined_node1)
        newnode.append(combined_node2)

        newnodes = []

        newnodes.append(newnode)
        newnodes = newnodes + newnode[2:]
        newnode = newnodes
        huffman_tree.append(nodes)
        combine(nodes)
    return huffman_tree
newnode = combine(nodes)

huffman_tree.sort(reverse=True)
print("Here is the huffman tree showing the merged nodes and binary pathways")

#removes duplicates
checklist = []
for level in huffman_tree:
    for node in level:
        if node not in checklist:
            checklist.append(node)
        else:
            level.remove(node)
count = 0
for level in huffman_tree:
    print("Level", count, ",", level)
    count += 1
print()

#builds the binary codes for each character
letter_binary = []
if len(only_letters) == 1:
    letter_code = [only_letters[0],"0"]
    letter_binary.append(letter_code*len(my_string))

#Output letters with binary codes
print("The binary codes of your string are")
for letter in letter_binary:
    print(letter[0], letter[1])

bitstring = ""
for character in my_string:
        for letter in letter_binary:
            if character in item:
                bitstring = bitstring + item

#Convert the string to an actual binary digit
binary = (bin(int(bitstring, base = 2)))

#Summary of data compression
uncompressed_file_size = len(my_string)*7
comprised_file_size = len(binary)-2
print("Original file size was",uncompressed_file_size,"bits. The compressed file size",comprised_file_size)
print("This is a saving of ",uncompressed_file_size-comprised_file_size,"bits, with a compression of ")

#Data compressed in binary digits
print("Your message as binary is")
print(binary)

bitstring = str(binary[2:])
uncompressed_string = ""
code = ""
for digit in bitstring:
    code = code + digit
    pos = 0
    for letter in letter_binary:
        if code == letter[1]:
            uncompressed_string = uncompressed_string + letter_binary[pos][0]
            code = ""
        pos += 1

print("Your Uncompressed data is",uncompressed_string)




