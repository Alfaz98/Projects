import tkinter as tk
from gms.graph import Graph
from gms.priority_queue import PriorityQueue



class Window:

    def __init__(self):
        self.window = tk.Tk()
        self.window.title("GOOGLE MAPS SIMULATOR")
        self.window.geometry("800x300")

        self.graph = None
        self.list_me = []
        self.clist = ['CHINHOYI', 'HARARE', 'KADOMA', 'MUTARE', 'GWERU', 'KARIBA', 'NORTON']

        def restart():
            self.graph = Graph()
            self.graph.add_weight('CHINHOYI', 'HARARE', 8)
            self.graph.add_weight('CHINHOYI', 'GWERU', 10)
            self.graph.add_weight('HARARE', 'GWERU', 5)
            self.graph.add_weight('HARARE', 'CHINHOYI', 8)
            self.graph.add_weight('HARARE', 'MUTARE', 2)
            self.graph.add_weight('HARARE', 'KADOMA', 3)
            self.graph.add_weight('KADOMA', 'HARARE', 3)
            self.graph.add_weight('KADOMA', 'MUTARE', 2)
            self.graph.add_weight('KADOMA', 'NORTON', 2)
            self.graph.add_weight('MUTARE', 'HARARE', 2)
            self.graph.add_weight('MUTARE', 'KADOMA', 2)
            self.graph.add_weight('MUTARE', 'NORTON', 5)
            self.graph.add_weight('MUTARE', 'GWERU', 5)
            self.graph.add_weight('MUTARE', 'KARIBA', 10)
            self.graph.add_weight('GWERU', 'CHINHOYI', 10)
            self.graph.add_weight('GWERU', 'HARARE', 5)
            self.graph.add_weight('GWERU', 'MUTARE', 5)
            self.graph.add_weight('GWERU', 'KARIBA', 13)
            self.graph.add_weight('KARIBA', 'GWERU', 13)
            self.graph.add_weight('KARIBA', 'MUTARE', 10)
            self.graph.add_weight('KARIBA', 'NORTON', 9)
            self.graph.add_weight('NORTON', 'MUTARE', 5)
            self.graph.add_weight('NORTON', 'KADOMA', 2)
            self.graph.add_weight('NORTON', 'KARIBA', 9)


        def dijkstra(graph, start):
            pq = PriorityQueue()
            start.setDistance(0)
            pq.buildHeap([(v.getDistance(), v) for v in graph])
            while not pq.is_empty():
                currentVert = pq.del_min()
                for nextVert in currentVert.getConnections():
                    newDist = currentVert.getDistance() \
                              + currentVert.getWeight(nextVert)
                    if newDist < nextVert.getDistance():
                        nextVert.setDistance(newDist)
                        nextVert.setPred(currentVert)
                        pq.decreaseKey(nextVert, newDist)

        def get_route(d):
            self.list_me.append(d.id)
            if d.pred is not None:
                get_route(d.pred)

        def show_map():
           self.map_route_show.config(text="")
           restart()
           a = self.graph.get_vertices()
           for i in a:
               self.map_route_show['text']  += str(self.graph.get_vertex(i)) +"\n"

        def get_shortest_route():
            restart()
            self.list_me.clear()
            good_to_go = True
            city = self.location_entry.get()
            realCity = city.upper()

            if realCity in self.clist:
                self.show_info.config(text="")
                source = self.graph.get_vertex(realCity)
                dijkstra(self.graph, source)

                city2 = self.destination_entry.get()
                realCity2 = city2.upper()
                if realCity2 in self.clist:
                    self.show_info.config(text="")
                    destination = self.graph.get_vertex(realCity2)
                    get_route(destination)
                else:
                    good_to_go = False
                    self.show_info.config(text="destination currently unavailable")

            else:
                good_to_go = False
                self.show_info.config(text = "location_X currently unavailable")


            if(good_to_go):
                self.map_route_show.config(text= "" + str(self.list_me[::-1]) +"\n"
                                           + "distance is: " + str(destination.getDistance()) + " km")


        self.location = tk.Label(text = "Location_X")
        self.location.grid(column = 0, row = 0, sticky = "E")
        self.destination = tk.Label(text = "Destination")
        self.destination.grid(column=0, row=1, sticky = "E")
        self.info = tk.Label(text = "Info")
        self.info.grid(column=0, row=3, sticky = "E")
        self.show_info = tk.Label(bg = "red" , height = 5)
        self.show_info.grid(column=0, row = 4, columnspan= 2)
        self.available_locations = tk.Label(text = "Available Locations")
        self.available_locations.grid(column=0, row=5, sticky = "E")
        self.available_locations_show = tk.Label(text = ">> Chinhoyi    >> Harare   >> Mutare\n"
                                                        ">> Kariba  >> Norton   >> Kadoma\n"
                                                        ">> Gweru", height = 5)
        self.available_locations_show.grid(column=0, row=6, columnspan= 3)
        self.map_route = tk.Label(text = "Map/Route")
        self.map_route.grid(column = 2, row = 0, sticky = "E")
        self.map_route_show = tk.Label(bg = "white")
        self.map_route_show.grid(column=2, row=1, sticky = "E", rowspan = 3)

        self.get_shortest_route = tk.Button(text = "Get Shortest Route", command = get_shortest_route)
        self.get_shortest_route.grid(column= 1, row = 2, sticky = "W")
        self.show_map = tk.Button(text="Show Map", command=show_map)
        self.show_map.grid(column=0, row=2, sticky="E")

        self.location_entry = tk.Entry()
        self.location_entry.grid(column=1, row=0)
        self.destination_entry = tk.Entry()
        self.destination_entry.grid(column=1, row=1)

        self.window.mainloop()
