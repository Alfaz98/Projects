from gms.window import Window


win = Window()
